# Emotion Detection Application

A web application that uses the Watson NLP library's EmotionPredict
service to detect the emotions (anger, disgust, fear, joy, sadness)
present in a piece of text, and reports the dominant emotion. The
application is deployed as a Flask web service with a simple HTML
front end.

## Project Structure
- `EmotionDetection/emotion_detection.py` – core emotion_detector function
- `EmotionDetection/__init__.py` – package initializer
- `test_emotion_detection.py` – unit tests
- `server.py` – Flask web server
- `templates/index.html` – web UI
- `requirements.txt` – dependencies

## Running Locally
```
pip install -r requirements.txt
python3 server.py
```
Then open the app and enter text to analyze in the input box.
