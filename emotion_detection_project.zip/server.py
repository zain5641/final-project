"""
server.py

Flask web application that exposes the emotion_detector function
as a simple web service with a UI (templates/index.html).
"""

from flask import Flask, render_template, request
from EmotionDetection.emotion_detection import emotion_detector

app = Flask("Emotion Detector")


@app.route("/emotionDetector")
def emo_detector():
    """
    Reads the 'textToAnalyze' query param, runs emotion detection,
    and returns a formatted sentence with the scores + dominant emotion.
    Handles blank/invalid input (Task 7).
    """
    text_to_analyze = request.args.get('textToAnalyze')

    response = emotion_detector(text_to_analyze)

    # Task 7 Activity 2: blank input -> emotion_detector returns all None
    if response['dominant_emotion'] is None:
        return "Invalid text! Please try again!"

    anger = response['anger']
    disgust = response['disgust']
    fear = response['fear']
    joy = response['joy']
    sadness = response['sadness']
    dominant_emotion = response['dominant_emotion']

    return (
        f"For the given statement, the system response is 'anger': {anger}, "
        f"'disgust': {disgust}, 'fear': {fear}, 'joy': {joy} and 'sadness': "
        f"{sadness}. The dominant emotion is {dominant_emotion}."
    )


@app.route("/")
def render_index_page():
    return render_template('index.html')


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
