"""
emotion_detection.py

Core module for the Emotion Detection application.
Uses the Watson NLP EmotionPredict service (via the Skills Network
public endpoint) to detect the emotions present in a piece of text.
"""

import json
import requests


def emotion_detector(text_to_analyse):
    """
    Sends the given text to the Watson NLP EmotionPredict service and
    returns a dictionary containing the scores for anger, disgust,
    fear, joy, sadness, plus the dominant emotion.

    Parameters:
        text_to_analyse (str): The text to run emotion detection on.

    Returns:
        dict: {
            'anger': float | None,
            'disgust': float | None,
            'fear': float | None,
            'joy': float | None,
            'sadness': float | None,
            'dominant_emotion': str | None
        }
        All values are None if the input text is blank / the service
        returns a 400 (Task 7 - error handling).
    """
    url = (
        'https://sn-watson-emotion.labs.skills.network/v1/'
        'watson.runtime.nlp.v1/NlpService/EmotionPredict'
    )
    headers = {
        "grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"
    }
    input_json = {"raw_document": {"text": text_to_analyse}}

    response = requests.post(url, json=input_json, headers=headers)

    # Task 7: blank/invalid input -> Watson NLP returns status 400
    if response.status_code == 400:
        return {
            'anger': None,
            'disgust': None,
            'fear': None,
            'joy': None,
            'sadness': None,
            'dominant_emotion': None
        }

    formatted_response = json.loads(response.text)
    emotion_predictions = formatted_response['emotionPredictions'][0]['emotion']

    anger = emotion_predictions['anger']
    disgust = emotion_predictions['disgust']
    fear = emotion_predictions['fear']
    joy = emotion_predictions['joy']
    sadness = emotion_predictions['sadness']

    emotions = {
        'anger': anger,
        'disgust': disgust,
        'fear': fear,
        'joy': joy,
        'sadness': sadness
    }

    # Task 3: dominant emotion = key with the highest score
    dominant_emotion = max(emotions, key=emotions.get)

    final_result = {
        'anger': anger,
        'disgust': disgust,
        'fear': fear,
        'joy': joy,
        'sadness': sadness,
        'dominant_emotion': dominant_emotion
    }

    return final_result
