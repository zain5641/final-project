"""
EmotionDetection package initializer.

Exposes the emotion_detector function so it can be imported directly
as:  from EmotionDetection import emotion_detector
"""

from .emotion_detection import emotion_detector
